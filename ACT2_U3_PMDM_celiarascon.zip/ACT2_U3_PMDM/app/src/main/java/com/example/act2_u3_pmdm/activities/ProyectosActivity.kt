package com.example.act2_u3_pmdm.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.act2_u3_pmdm.adapter.ProyectoAdapter
import com.example.act2_u3_pmdm.database.AppDatabase
import com.example.act2_u3_pmdm.databinding.ActivityProyectosBinding
import kotlinx.coroutines.launch

class ProyectosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProyectosBinding
    private lateinit var db: AppDatabase
    private lateinit var adapter: ProyectoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProyectosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = AppDatabase.getDatabase(this)

        adapter = ProyectoAdapter(emptyList()) { proyecto ->
            val intent = Intent(this, DetalleProyectoActivity::class.java)
            intent.putExtra("proyecto", proyecto)
            startActivity(intent)
        }

        binding.recyclerViewProyectos.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewProyectos.adapter = adapter

        loadProyectos()

        binding.btnCrearProyecto.setOnClickListener {
            val intent = Intent(this, CrearProyectoActivity::class.java)
            startActivity(intent)
        }
    }

    private fun loadProyectos() {
        lifecycleScope.launch {
            val proyectosConLenguaje = db.proyectoDao().obtenerProyectosConLenguaje()
            val proyectos = proyectosConLenguaje.map { it.toProyecto() }
            adapter.submitList(proyectos)
        }
    }
}
