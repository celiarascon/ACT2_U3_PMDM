package com.example.act2_u3_pmdm.database

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity
data class Lenguaje(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String
) : Parcelable
