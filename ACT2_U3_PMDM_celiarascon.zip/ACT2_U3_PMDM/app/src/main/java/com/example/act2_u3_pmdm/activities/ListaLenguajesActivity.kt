package com.example.act2_u3_pmdm.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.act2_u3_pmdm.adapter.LenguajeAdapter
import com.example.act2_u3_pmdm.database.AppDatabase
import com.example.act2_u3_pmdm.databinding.ActivityListaLenguajesBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ListaLenguajesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListaLenguajesBinding
    private lateinit var adapter: LenguajeAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListaLenguajesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvLenguajes.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@ListaLenguajesActivity)
            val lenguajesFlow = db.lenguajeDao().obtenerLenguajes()

            lenguajesFlow.collect { lenguajes ->
                withContext(Dispatchers.Main) {
                    adapter = LenguajeAdapter(lenguajes)
                    binding.rvLenguajes.adapter = adapter
                }
            }
        }
    }
}
