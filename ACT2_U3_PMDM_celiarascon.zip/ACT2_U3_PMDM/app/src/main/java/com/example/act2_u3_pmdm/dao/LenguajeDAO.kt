package com.example.act2_u3_pmdm.dao

import com.example.act2_u3_pmdm.database.Lenguaje
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LenguajeDao {
    @Insert
    suspend fun insertarLenguaje(lenguaje: Lenguaje)

    @Query("SELECT * FROM Lenguaje")
    fun obtenerLenguajes(): Flow<List<Lenguaje>>
}


