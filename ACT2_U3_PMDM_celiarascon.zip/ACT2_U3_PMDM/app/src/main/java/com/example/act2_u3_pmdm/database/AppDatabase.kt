package com.example.act2_u3_pmdm.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.act2_u3_pmdm.dao.LenguajeDao
import com.example.act2_u3_pmdm.dao.ProyectoDao

@Database(entities = [Lenguaje::class, Proyecto::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lenguajeDao(): LenguajeDao
    abstract fun proyectoDao(): ProyectoDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

