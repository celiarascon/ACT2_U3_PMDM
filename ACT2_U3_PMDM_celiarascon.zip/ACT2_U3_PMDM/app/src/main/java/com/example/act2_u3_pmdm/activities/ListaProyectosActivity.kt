package com.example.act2_u3_pmdm.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.act2_u3_pmdm.adapter.ProyectoAdapter
import com.example.act2_u3_pmdm.database.AppDatabase
import com.example.act2_u3_pmdm.databinding.ActivityListaProyectosBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ListaProyectosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListaProyectosBinding
    private lateinit var adapter: ProyectoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListaProyectosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvProyecto.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(this@ListaProyectosActivity)
            val proyectosFlow = db.proyectoDao().obtenerProyectos()

            proyectosFlow.collect { proyectos ->
                withContext(Dispatchers.Main) {
                    adapter = ProyectoAdapter(proyectos) { proyecto ->
                        val intent =
                            Intent(this@ListaProyectosActivity, DetalleProyectoActivity::class.java)
                        intent.putExtra("proyecto", proyecto)
                        startActivity(intent)
                    }
                    binding.rvProyecto.adapter = adapter
                }
            }
        }
    }
}
