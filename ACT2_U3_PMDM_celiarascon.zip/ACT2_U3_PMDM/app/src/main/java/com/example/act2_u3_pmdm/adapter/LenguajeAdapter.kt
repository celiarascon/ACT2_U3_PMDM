package com.example.act2_u3_pmdm.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.act2_u3_pmdm.R
import com.example.act2_u3_pmdm.database.Lenguaje

class LenguajeAdapter(private val listaLenguajes: List<Lenguaje>) :
    RecyclerView.Adapter<LenguajeAdapter.LenguajeViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LenguajeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_lenguaje, parent, false)
        return LenguajeViewHolder(view)
    }

    override fun onBindViewHolder(holder: LenguajeViewHolder, position: Int) {
        val lenguaje = listaLenguajes[position]
        holder.tvNombreLenguaje.text = lenguaje.nombre
    }

    override fun getItemCount(): Int = listaLenguajes.size

    class LenguajeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNombreLenguaje: TextView = itemView.findViewById(R.id.tvNombreLenguaje)
    }
}
