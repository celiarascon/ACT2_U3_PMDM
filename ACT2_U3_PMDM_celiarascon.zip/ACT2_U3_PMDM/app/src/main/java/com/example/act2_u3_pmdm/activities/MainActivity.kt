package com.example.act2_u3_pmdm.activities

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.act2_u3_pmdm.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupFloatingActionButton()
    }

    private fun setupFloatingActionButton() {
        binding.btnAgregarProyecto.visibility = View.GONE
        binding.btnAgregarLenguaje.visibility = View.GONE
        binding.btnVerListaProyectos.visibility = View.GONE
        binding.btnVerListaLenguajes.visibility = View.GONE

        binding.fabMenu.setOnClickListener {
            if (binding.btnAgregarProyecto.visibility == View.GONE) {
                binding.btnAgregarProyecto.visibility = View.VISIBLE
                binding.btnAgregarLenguaje.visibility = View.VISIBLE
                binding.btnVerListaProyectos.visibility = View.VISIBLE
                binding.btnVerListaLenguajes.visibility = View.VISIBLE
            } else {
                binding.btnAgregarProyecto.visibility = View.GONE
                binding.btnAgregarLenguaje.visibility = View.GONE
                binding.btnVerListaProyectos.visibility = View.GONE
                binding.btnVerListaLenguajes.visibility = View.GONE
            }
        }

        binding.btnAgregarProyecto.setOnClickListener {
            val intent = Intent(this, CrearProyectoActivity::class.java)
            startActivity(intent)
        }

        binding.btnAgregarLenguaje.setOnClickListener {
            val intent = Intent(this, CrearLenguajeActivity::class.java)
            startActivity(intent)
        }

        binding.btnVerListaProyectos.setOnClickListener {
            val intent = Intent(this, ListaProyectosActivity::class.java)
            startActivity(intent)
        }

        binding.btnVerListaLenguajes.setOnClickListener {
            val intent = Intent(this, ListaLenguajesActivity::class.java)
            startActivity(intent)
        }
    }
}
