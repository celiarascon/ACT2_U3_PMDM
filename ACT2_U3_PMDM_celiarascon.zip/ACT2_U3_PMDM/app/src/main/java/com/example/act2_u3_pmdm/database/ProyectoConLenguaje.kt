package com.example.act2_u3_pmdm.database

import java.io.Serializable

data class ProyectoConLenguaje(
    val proyectoId: Int,
    val nombreProyecto: String,
    val nombreLenguaje: String,
    val prioridad: String
) : Serializable {
    fun toProyecto(): Proyecto {
        return Proyecto(
            id = proyectoId,
            nombre = nombreProyecto,
            prioridad = prioridad,
            descripcion = "",
            tiempo = 0,
            fechaInicio = "",
            lenguajeId = 0
        )
    }
}
