package com.example.act2_u3_pmdm.activities

import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.act2_u3_pmdm.R
import com.example.act2_u3_pmdm.database.AppDatabase
import com.example.act2_u3_pmdm.database.Proyecto
import com.example.act2_u3_pmdm.databinding.ActivityCrearProyectoBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*

class CrearProyectoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCrearProyectoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCrearProyectoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = AppDatabase.getDatabase(this)

        lifecycleScope.launch(Dispatchers.IO) {
            db.lenguajeDao().obtenerLenguajes().collect { lenguajes ->
                val nombresLenguajes = lenguajes.map { it.nombre }

                runOnUiThread {
                    val adapter = ArrayAdapter(
                        this@CrearProyectoActivity,
                        android.R.layout.simple_spinner_item,
                        nombresLenguajes
                    )
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binding.spLenguaje.adapter = adapter

                    val adapterPrioridad = ArrayAdapter.createFromResource(
                        this@CrearProyectoActivity,
                        R.array.prioridades,
                        android.R.layout.simple_spinner_item
                    )
                    adapterPrioridad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    binding.spPrioridadProyecto.adapter = adapterPrioridad
                }
            }
        }

        binding.btnSeleccionaDia.setOnClickListener {
            val calendar = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    val fecha = getString(R.string.fecha_formato, dayOfMonth, month + 1, year)
                    binding.tvSeleccionaDia.text = fecha
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        binding.btnGuardarProyecto.setOnClickListener {
            val nombre = binding.etNombreProyecto.text.toString()
            val tiempo = binding.etTiempoProyecto.text.toString().toIntOrNull()
            val prioridad = binding.spPrioridadProyecto.selectedItem.toString()
            val descripcion = binding.etDescripcionProyecto.text.toString()
            val fechaInicio = binding.tvSeleccionaDia.text.toString()
            val lenguajeSeleccionado = binding.spLenguaje.selectedItem?.toString()

            if (nombre.isNotEmpty() && tiempo != null && lenguajeSeleccionado != null) {
                lifecycleScope.launch(Dispatchers.IO) {
                    db.lenguajeDao().obtenerLenguajes().collect { lenguajes ->
                        val lenguaje = lenguajes.firstOrNull { it.nombre == lenguajeSeleccionado }

                        if (lenguaje != null) {
                            val lenguajeId = lenguaje.id
                            db.proyectoDao().insertarProyecto(
                                Proyecto(
                                    nombre = nombre,
                                    tiempo = tiempo,
                                    prioridad = prioridad,
                                    descripcion = descripcion,
                                    fechaInicio = fechaInicio,
                                    lenguajeId = lenguajeId
                                )
                            )
                        } else {
                            runOnUiThread {
                                Toast.makeText(
                                    this@CrearProyectoActivity,
                                    "Lenguaje no encontrado",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                }
            }
        }
    }
}
