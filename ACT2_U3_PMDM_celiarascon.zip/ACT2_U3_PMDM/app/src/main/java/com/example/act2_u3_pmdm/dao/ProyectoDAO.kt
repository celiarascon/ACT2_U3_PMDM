package com.example.act2_u3_pmdm.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.act2_u3_pmdm.database.Proyecto
import com.example.act2_u3_pmdm.database.ProyectoConLenguaje
import kotlinx.coroutines.flow.Flow

@Dao
interface ProyectoDao {

    @Insert
    suspend fun insertarProyecto(proyecto: Proyecto)

    @Query("SELECT * FROM Proyecto")
    fun obtenerProyectos(): Flow<List<Proyecto>>

    @Update
    suspend fun actualizarProyecto(proyecto: Proyecto)

    @Query(
        """
        SELECT 
            proyecto.id AS proyectoId,
            proyecto.nombre AS nombreProyecto,
            lenguaje.nombre AS nombreLenguaje,
            proyecto.prioridad AS prioridad
        FROM Proyecto AS proyecto
        INNER JOIN Lenguaje AS lenguaje ON proyecto.lenguajeId = lenguaje.id
    """
    )
    fun obtenerProyectosConLenguaje(): List<ProyectoConLenguaje>
}
