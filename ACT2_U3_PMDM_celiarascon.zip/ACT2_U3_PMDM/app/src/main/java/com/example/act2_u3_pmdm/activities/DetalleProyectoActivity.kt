package com.example.act2_u3_pmdm.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.act2_u3_pmdm.database.AppDatabase
import com.example.act2_u3_pmdm.database.Proyecto
import com.example.act2_u3_pmdm.databinding.ActivityDetalleProyectoBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.*

class DetalleProyectoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetalleProyectoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetalleProyectoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val proyecto = intent.getParcelableExtra("proyecto", Proyecto::class.java)
        if (proyecto == null) {
            Toast.makeText(this, "Error: Proyecto no encontrado", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val db = AppDatabase.getDatabase(this)

        binding.etNombreProyecto.setText(proyecto.nombre)
        binding.etPrioridadProyecto.setText(proyecto.prioridad)
        binding.etDescripcionProyecto.setText(proyecto.descripcion)

        val formatter = NumberFormat.getInstance(Locale.getDefault())
        binding.etTiempoProyecto.setText(formatter.format(proyecto.tiempo))

        binding.tvFechaInicio.text = proyecto.fechaInicio

        binding.btnGuardarDetalles.setOnClickListener {
            val tiempoStr = binding.etTiempoProyecto.text.toString()
            val tiempo = try {
                formatter.parse(tiempoStr)?.toInt() ?: 0
            } catch (e: Exception) {
                Toast.makeText(this, "Tiempo inválido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            proyecto.nombre = binding.etNombreProyecto.text.toString()
            proyecto.prioridad = binding.etPrioridadProyecto.text.toString()
            proyecto.descripcion = binding.etDescripcionProyecto.text.toString()
            proyecto.tiempo = tiempo

            lifecycleScope.launch(Dispatchers.IO) {
                db.proyectoDao().actualizarProyecto(proyecto)
                runOnUiThread {
                    Toast.makeText(
                        this@DetalleProyectoActivity,
                        "Cambios guardados",
                        Toast.LENGTH_SHORT
                    ).show()
                    finish()
                }
            }
        }
    }
}
