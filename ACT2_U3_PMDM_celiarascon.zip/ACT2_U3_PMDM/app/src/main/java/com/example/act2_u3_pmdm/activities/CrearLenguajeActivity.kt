package com.example.act2_u3_pmdm.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.act2_u3_pmdm.database.AppDatabase
import com.example.act2_u3_pmdm.database.Lenguaje
import com.example.act2_u3_pmdm.databinding.ActivityCrearLenguajeBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.widget.Toast

class CrearLenguajeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCrearLenguajeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCrearLenguajeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val db = AppDatabase.getDatabase(this)

        binding.btnGuardarLenguaje.setOnClickListener {
            val nombreLenguaje = binding.etNombreLenguaje.text.toString()

            if (nombreLenguaje.isNotEmpty()) {
                val nuevoLenguaje = Lenguaje(nombre = nombreLenguaje)

                lifecycleScope.launch(Dispatchers.IO) {
                    db.lenguajeDao().insertarLenguaje(nuevoLenguaje)
                    runOnUiThread {
                        val resultIntent = Intent()
                        resultIntent.putExtra(
                            "nuevo_lenguaje",
                            nuevoLenguaje
                        )
                        setResult(Activity.RESULT_OK, resultIntent)
                        Toast.makeText(
                            this@CrearLenguajeActivity,
                            "Lenguaje guardado",
                            Toast.LENGTH_SHORT
                        ).show()
                        finish()
                    }
                }
            } else {
                Toast.makeText(this, "Introduce un nombre", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
