package com.example.act2_u3_pmdm.database

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "Proyecto")
data class Proyecto(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    var nombre: String,
    var prioridad: String,
    var descripcion: String,
    var tiempo: Int,
    var fechaInicio: String,
    val lenguajeId: Int
) : Parcelable
