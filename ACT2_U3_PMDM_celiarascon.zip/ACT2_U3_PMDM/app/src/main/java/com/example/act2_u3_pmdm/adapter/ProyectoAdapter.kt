package com.example.act2_u3_pmdm.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.act2_u3_pmdm.database.Proyecto
import com.example.act2_u3_pmdm.databinding.ItemProyectoBinding

class ProyectoAdapter(
    private var proyectos: List<Proyecto>,
    private val onProyectoClicked: (Proyecto) -> Unit
) : RecyclerView.Adapter<ProyectoAdapter.ProyectoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProyectoViewHolder {
        val binding =
            ItemProyectoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProyectoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProyectoViewHolder, position: Int) {
        val proyecto = proyectos[position]
        holder.bind(proyecto)
    }

    override fun getItemCount(): Int = proyectos.size

    @SuppressLint("NotifyDataSetChanged")
    fun submitList(proyectos: List<Proyecto>) {
        this.proyectos = proyectos
        notifyDataSetChanged()
    }

    inner class ProyectoViewHolder(private val binding: ItemProyectoBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(proyecto: Proyecto) {
            binding.tvNombreProyecto.text = proyecto.nombre
            binding.tvPrioridad.text = proyecto.prioridad
            binding.root.setOnClickListener {
                onProyectoClicked(proyecto)
            }
        }
    }
}

